[AngryBirds] - Initial submission
Currently implemented features
[Revolute joint on the circle, that makes it revolve around the cube after being hit by the bird]
[One bird that can be shot using the mouse]
    [Click on the bird to begin, move the mouse to adjust position, release to shoot]
[There are three blocks in the game]
[Release build was having errors so here's the Debug]
[Press R to restart the scene]
[What I need to do]
    [Create a vector to store and draw all the objects rather than drawing thm individually]
    [Create enemies that can be killed using the birds]
    [Commenting]
    [Create multiplle scenes]
    [Create main menu, pause and game over screens]