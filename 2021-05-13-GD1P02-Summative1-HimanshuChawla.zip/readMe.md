[AngryBirds] - Final Submission
[LMB] to began shooting,
Move the mouse to select direction,
Release [LMB] to shoot in the selected direction.
While Bird is airborne press [LMB] to activate ability (Not for red)

Green plank is destructable,
Grey planks are indestructable.

Once all enemies are destroyed in the level, the player proceeds to the next level.
After level 2, the player proceeds to win screen.
At any point if no grumpy birds are left, the player proceeds to lose screen.