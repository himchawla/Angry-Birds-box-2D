#pragma once
#include "sprite.h"
class Bird :
	public sprite
{
public:
	int speed;
	int mass;

private:

};

